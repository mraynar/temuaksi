import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import '../../theme/app_colors.dart';
import 'topup_saldo_page.dart';
import 'riwayat_transaksi_page.dart';
import 'profil_publik_page.dart';
import 'verifikasi_bisnis_page.dart';
import 'manajemen_tim_page.dart';
import '../../utils/logout_helper.dart';
import '../../individu/profile/keamanan_page.dart' show SecurityPage;

class CompanyProfilePage extends StatefulWidget {
  const CompanyProfilePage({super.key});

  @override
  State<CompanyProfilePage> createState() => _CompanyProfilePageState();
}

class _CompanyProfilePageState extends State<CompanyProfilePage> {
  final User? user = FirebaseAuth.instance.currentUser;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final String cloudName = "dm4ua5rj6";
  final String uploadPreset = "temu_aksi_preset";
  bool _isUploadingPhoto = false;

  final NumberFormat _currencyFormat = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  void _handleLogout() async {
    await handleLogout(context);
  }

  void _go(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      backgroundColor: AppColors.neutral,
      body: StreamBuilder<DocumentSnapshot>(
        stream: _firestore.collection('users').doc(user!.uid).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text("Error"));
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          var userData = snapshot.data?.data() as Map<String, dynamic>?;

          String companyName = userData?['nama_lengkap'] ?? 'Company Name';
          String industry = userData?['bidang_industri'] ?? 'Sektor Industri';
          String location = userData?['alamat'] ?? 'Lokasi tidak diatur';
          String photoUrl = userData?['photo_url'] ?? '';
          bool isVerified = userData?['isVerified'] ?? false;
          int saldo = userData?['saldo_csr'] ?? 0;

          return CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              _buildCompanyHeader(
                  companyName, industry, location, photoUrl, isVerified),
              SliverPadding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    _buildBalanceCard(saldo),
                    const SizedBox(height: 24),
                    _buildImpactStats(),
                    const SizedBox(height: 32),
                    _buildSectionLabel("KEUANGAN & CSR"),
                    _buildMenuContainer([
                      _buildMenuItem(
                          Icons.account_balance_wallet_rounded,
                          "Top Up Saldo Aksi",
                          "Tambah anggaran untuk kegiatan CSR", () {
                        _go(const TopUpSaldoPage());
                      }),
                      _buildMenuItem(
                          Icons.receipt_long_rounded,
                          "Riwayat Transaksi",
                          "Lihat penggunaan dana CSR",
                          () => _go(const RiwayatTransaksiPage())),
                    ]),
                    const SizedBox(height: 32),
                    _buildSectionLabel("FOTO PERUSAHAAN"),
                    const SizedBox(height: 12),
                    _buildCompanyPhotosSection(userData),
                    const SizedBox(height: 24),
                    _buildSectionLabel("PROFESIONAL & LEGALITAS"),
                    _buildMenuContainer([
                      _buildMenuItem(
                          Icons.storefront_rounded,
                          "Profil Publik Perusahaan",
                          "Atur deskripsi dan portofolio",
                          () => _go(const ProfilPublikPage())),
                      _buildMenuItem(
                          Icons.verified_user_outlined,
                          "Verifikasi Bisnis",
                          "NPWP, NIB, & Dokumen Legal",
                          () => _go(const VerifikasiBisnisPage())),
                    ]),
                    const SizedBox(height: 24),
                    _buildSectionLabel("PENGATURAN ORGANISASI"),
                    _buildMenuContainer([
                      _buildMenuItem(Icons.people_outline_rounded,
                          "Manajemen Tim", "Atur admin pengelola akun",
                          () => _go(const ManajemenTimPage())),
                      _buildMenuItem(Icons.security_rounded, "Keamanan Akun",
                          "Sandi & akses API",
                          () => _go(const SecurityPage())),
                    ]),
                    const SizedBox(height: 32),
                    _buildLogoutButton(),
                    const SizedBox(height: 40),
                  ]),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildBalanceCard(int amount) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.primary,
            AppColors.primary.withValues(alpha: 0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.2),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Saldo Anggaran CSR",
                style: GoogleFonts.plusJakartaSans(
                  color: Colors.white.withValues(alpha: 0.7),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
              Icon(
                Icons.account_balance_wallet_rounded,
                color: Colors.white.withValues(alpha: 0.4),
                size: 20,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _currencyFormat.format(amount),
            style: GoogleFonts.plusJakartaSans(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.info_outline_rounded,
                  color: Colors.white,
                  size: 14,
                ),
                const SizedBox(width: 8),
                Text(
                  "Dana siap dialokasikan untuk aksi sosial",
                  style: GoogleFonts.plusJakartaSans(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompanyHeader(String name, String industry, String location,
      String url, bool verified) {
    return SliverAppBar(
      expandedHeight: 280,
      pinned: true,
      backgroundColor: AppColors.primary,
      elevation: 0,
      flexibleSpace: FlexibleSpaceBar(
        background: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [Color(0xFF2563EB), AppColors.primary],
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 50),
                Stack(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(4.5),
                      decoration: const BoxDecoration(
                          color: Colors.white, shape: BoxShape.circle),
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: AppColors.neutral,
                        backgroundImage:
                            url.isNotEmpty ? NetworkImage(url) : null,
                        child: url.isEmpty
                            ? const Icon(Icons.business_rounded,
                                size: 45, color: AppColors.primary)
                            : null,
                      ),
                    ),
                    if (verified)
                      Positioned(
                        right: 2,
                        bottom: 2,
                        child: Container(
                          padding: const EdgeInsets.all(2.5),
                          decoration: const BoxDecoration(
                              color: Colors.white, shape: BoxShape.circle),
                          child: const Icon(Icons.verified_rounded,
                              color: Colors.blue, size: 26),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    name,
                    textAlign: TextAlign.center,
                    style: GoogleFonts.plusJakartaSans(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.5),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  industry,
                  style: GoogleFonts.plusJakartaSans(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 15,
                      fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.location_on_rounded,
                        color: Colors.white70, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      location,
                      style: GoogleFonts.plusJakartaSans(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Impact stats with live Firestore data
  Widget _buildImpactStats() {
    final uid = user!.uid;

    return StreamBuilder<List<QuerySnapshot>>(
      stream: Stream.fromFuture(Future.wait([
        _firestore
            .collection('aksi')
            .where('perusahaan_id', isEqualTo: uid)
            .where('status', isEqualTo: 'aktif')
            .get(),
        _firestore
            .collection('aksi')
            .where('perusahaan_id', isEqualTo: uid)
            .get(),
        _firestore
            .collection('proposals')
            .where('perusahaan_id', isEqualTo: uid)
            .where('status', isEqualTo: 'diterima')
            .get(),
      ])),
      builder: (context, snapshot) {
        int aksiAktif = 0;
        int totalRelawan = 0;
        int partner = 0;

        if (snapshot.hasData) {
          aksiAktif = snapshot.data![0].docs.length;

          for (final doc in snapshot.data![1].docs) {
            final data = doc.data() as Map<String, dynamic>;
            totalRelawan += (data['jumlah_relawan'] as num?)?.toInt() ?? 0;
          }

          partner = snapshot.data![2].docs.length;
        }

        String relawanLabel = totalRelawan >= 1000
            ? '${(totalRelawan / 1000).toStringAsFixed(1)}k'
            : totalRelawan.toString();

        return Container(
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 20,
                  offset: const Offset(0, 10))
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStatColumn(aksiAktif.toString(), "Aksi Aktif"),
              _buildDivider(),
              _buildStatColumn(relawanLabel, "Total Relawan"),
              _buildDivider(),
              _buildStatColumn(partner.toString(), "Partner"),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatColumn(String val, String label) {
    return Column(
      children: [
        Text(val,
            style: GoogleFonts.plusJakartaSans(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppColors.primary)),
        const SizedBox(height: 4),
        Text(label,
            style: GoogleFonts.plusJakartaSans(
                fontSize: 12, color: Colors.grey, fontWeight: FontWeight.w500)),
      ],
    );
  }

  Widget _buildDivider() =>
      Container(height: 30, width: 1, color: Colors.grey.withOpacity(0.2));

  Widget _buildSectionLabel(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 12),
      child: Text(
        title,
        style: GoogleFonts.plusJakartaSans(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: Colors.grey,
            letterSpacing: 1.2),
      ),
    );
  }

  Widget _buildMenuContainer(List<Widget> children) {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildMenuItem(
      IconData icon, String title, String subtitle, VoidCallback onTap) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: AppColors.neutral, borderRadius: BorderRadius.circular(14)),
        child: Icon(icon, color: AppColors.primary, size: 22),
      ),
      title: Text(title,
          style: GoogleFonts.plusJakartaSans(
              fontSize: 15, fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle,
          style: GoogleFonts.plusJakartaSans(fontSize: 12, color: Colors.grey)),
      trailing: const Icon(Icons.arrow_forward_ios_rounded,
          size: 14, color: Colors.black26),
    );
  }

  Widget _buildLogoutButton() {
    return InkWell(
      onTap: _handleLogout,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: AppColors.error.withOpacity(0.08),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Center(
          child: Text(
            "Keluar Akun",
            style: GoogleFonts.plusJakartaSans(
                color: AppColors.error,
                fontWeight: FontWeight.w700,
                fontSize: 15),
          ),
        ),
      ),
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.plusJakartaSans()),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<String?> _uploadToCloudinary(File file) async {
    final url =
        Uri.parse("https://api.cloudinary.com/v1_1/$cloudName/image/upload");

    var request = http.MultipartRequest("POST", url);
    request.fields['upload_preset'] = uploadPreset;
    request.files.add(await http.MultipartFile.fromPath('file', file.path));

    try {
      var response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await response.stream.toBytes();
        var responseString = String.fromCharCodes(responseData);
        var jsonRes = jsonDecode(responseString);
        return jsonRes['secure_url'];
      }
    } catch (e) {
      debugPrint("Cloudinary Error: $e");
    }
    return null;
  }

  Widget _buildCompanyPhotosSection(Map<String, dynamic>? userData) {
    final photosList = userData?['company_photos'] != null
        ? List<String>.from(userData!['company_photos'])
        : <String>[];

    return SizedBox(
      height: 120,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: photosList.length + (photosList.length < 5 ? 1 : 0),
        itemBuilder: (context, index) {
          if (index == photosList.length) {
            return _buildAddPhotoCard();
          }

          final photoUrl = photosList[index];
          return _buildPhotoCard(photoUrl, index);
        },
      ),
    );
  }

  Widget _buildAddPhotoCard() {
    return GestureDetector(
      onTap: _isUploadingPhoto ? null : _pickAndUploadPhoto,
      child: Container(
        width: 110,
        height: 110,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
        ),
        child: _isUploadingPhoto
            ? const Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.add_photo_alternate_outlined,
                      color: AppColors.primary, size: 28),
                  const SizedBox(height: 6),
                  Text(
                    "Tambah Foto",
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildPhotoCard(String url, int index) {
    return GestureDetector(
      onTap: () => _showPhotoActions(url, index),
      child: Container(
        width: 110,
        height: 110,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network(
            url,
            width: 110,
            height: 110,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: AppColors.neutral,
              child: const Icon(Icons.broken_image_outlined, color: Colors.grey),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickAndUploadPhoto() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 50);
    if (pickedFile == null) return;

    setState(() => _isUploadingPhoto = true);

    try {
      final file = File(pickedFile.path);
      final String? uploadedUrl = await _uploadToCloudinary(file);
      if (uploadedUrl == null) throw Exception("Gagal mengunggah foto");

      if (user != null) {
        await _firestore.collection('users').doc(user!.uid).update({
          'company_photos': FieldValue.arrayUnion([uploadedUrl])
        });
        _showSnackBar("Foto berhasil ditambahkan", AppColors.primary);
      }
    } catch (e) {
      _showSnackBar("Gagal mengunggah foto: $e", Colors.redAccent);
    } finally {
      setState(() => _isUploadingPhoto = false);
    }
  }

  void _showPhotoActions(String url, int index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            ListTile(
              leading: const Icon(Icons.sync_rounded, color: AppColors.primary),
              title: Text(
                "Ganti Foto",
                style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600),
              ),
              onTap: () {
                Navigator.pop(context);
                _replacePhoto(url);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
              title: Text(
                "Hapus Foto",
                style: GoogleFonts.plusJakartaSans(
                  fontWeight: FontWeight.w600,
                  color: Colors.redAccent,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _deletePhoto(url);
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Future<void> _deletePhoto(String url) async {
    if (user == null) return;
    try {
      await _firestore.collection('users').doc(user!.uid).update({
        'company_photos': FieldValue.arrayRemove([url])
      });
      _showSnackBar("Foto berhasil dihapus", AppColors.primary);
    } catch (e) {
      _showSnackBar("Gagal menghapus foto: $e", Colors.redAccent);
    }
  }

  Future<void> _replacePhoto(String oldUrl) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 50);
    if (pickedFile == null) return;

    setState(() => _isUploadingPhoto = true);

    try {
      final file = File(pickedFile.path);
      final String? newUrl = await _uploadToCloudinary(file);
      if (newUrl == null) throw Exception("Gagal mengunggah foto baru");

      if (user != null) {
        final doc = await _firestore.collection('users').doc(user!.uid).get();
        if (doc.exists) {
          final data = doc.data() as Map<String, dynamic>;
          final List<String> photos = List<String>.from(data['company_photos'] ?? []);
          final idx = photos.indexOf(oldUrl);
          if (idx != -1) {
            photos[idx] = newUrl;
            await _firestore.collection('users').doc(user!.uid).update({
              'company_photos': photos,
            });
            _showSnackBar("Foto berhasil diganti", AppColors.primary);
          } else {
            await _firestore.collection('users').doc(user!.uid).update({
              'company_photos': FieldValue.arrayRemove([oldUrl])
            });
            await _firestore.collection('users').doc(user!.uid).update({
              'company_photos': FieldValue.arrayUnion([newUrl])
            });
            _showSnackBar("Foto berhasil diganti", AppColors.primary);
          }
        }
      }
    } catch (e) {
      _showSnackBar("Gagal mengganti foto: $e", Colors.redAccent);
    } finally {
      setState(() => _isUploadingPhoto = false);
    }
  }
}
